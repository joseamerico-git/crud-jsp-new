package view;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.Normalizer;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.swing.JOptionPane;

import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import com.ibm.icu.text.SimpleDateFormat;

import beans.Etiqueta;
import beans.ItemVenda;
import beans.Venda;
import dao.ItemVendaDao;
import uteis.EncodeUTF8;

public class EscolherImpressoraViewEtiquetaAction extends EscolherImpressoraViewEtiquetas {

	private PrintService[] services = PrintServiceLookup.lookupPrintServices(null, null);

	String texto = "Algo a ser impresso, use caracteres de formatação relativos ao modelo da impressora";
	private int index = -1;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

	public EscolherImpressoraViewEtiquetaAction() {
		
		// testando quebra delinhas funcao

		String novoTexto = ("     \n\n" + "                              CUPOM FISCAL         "
				+ "                            \n" + "Pedido: 001         16/07/2024\n" + "Itens: \n" +

				"01 - Óleo de soja COAMO 900ml  KG  6,80 2  13,60 \n"
				+ "01 - Óleo de soja COAMO 900ml  KG  6,80 2  13,60 \n"
				+ "                               total:    27,30     "
				+ "\n Obrigado pela preferência! \n\n Volte sempre!");
		File file = new File("novoCupom.txt");
		if (!file.exists()) {
			System.out.println("Existe");
			try {
				file.createNewFile();
				System.out.println("Arquivo criado!");

				// Fluxo de saida de um arquivo
				OutputStream os = new FileOutputStream("novoCupom.txt"); // nome do arquivo que será escrito
				Writer wr = new OutputStreamWriter(os); // criação de um escritor
				BufferedWriter br = new BufferedWriter(wr); // adiciono a um escritor de buffer

				br.write(novoTexto);
				br.newLine();

				br.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.texto = novoTexto;

		txtTesteDeImpressora.setText(this.texto);
		getDataText();
		eventoBotao();

		carregaComboImpressoras();
		criarJanela();

	}

	private void getDataText() {

		Date data = new Date();// sdf.parse(this.data);
		textData.setText(sdf.format(data));

	}
	
	
	public double calculaTotal(List<ItemVenda> itens) {
		double total = 0;
		for (ItemVenda i : itens) {
			if (i.getProduto().getUnidade().contains("UN")) {
				total = total + i.getPrecoUnitario() * i.getQuantidade();
			}

			if (i.getProduto().getUnidade().contains("KG")) {
				total = total + i.getPrecoUnitario() * i.getQuantidade() / 1000;
			}
		}
		return total;
	}

	public EscolherImpressoraViewEtiquetaAction(Venda venda) {
		eventoBotao();
		// testando quebra delinhas funcao
		List<ItemVenda> itens = new ItemVendaDao().getItemVendaIdVenda(venda.getId());

		String lista = "	                CUPOM FISCAL           \n" + "		                                   \n"
				+ "Pedido: " + venda.getId() + "         " + venda.getDataVenda() + "          \n"
				+ "Itens:                                    \n";

		lista = lista + "COD DESC PREÇO QTDE SUBTOTAL    \n";

		for (int i = 0; i < itens.size(); i++) {
			double subtotal = 0;
			if (itens.get(i).getProduto().getUnidade().contains("UN")) {
				subtotal = subtotal + itens.get(i).getPrecoUnitario() * itens.get(i).getQuantidade();
			}

			if (itens.get(i).getProduto().getUnidade().contains("KG")) {
				subtotal = subtotal + itens.get(i).getPrecoUnitario() * itens.get(i).getQuantidade() / 1000;
			}
			lista = lista + (i + 1) + " - " + itens.get(i).getProduto().getNome() + " "
					+ itens.get(i).getProduto().getUnidade() + " " + itens.get(i).getProduto().getPreco() + " "
					+ itens.get(i).getQuantidade() + " " + subtotal + "\n";

		}

		lista = lista + "\n Obrigado pela preferência! \n\n Volte sempre!";
		lista = lista + "\n                      TOTAL: " + calculaTotal(itens);
		this.texto = lista;

		System.out.println(venda.getEntrada());

		String novoTexto = lista;

		File file = new File("novoCupom.txt");
		if (!file.exists()) {
			System.out.println("Existe");
			try {
				file.createNewFile();
				System.out.println("Arquivo criado!");

				// Fluxo de saida de um arquivo
				OutputStream os = new FileOutputStream("novoCupom.txt"); // nome do arquivo que será escrito
				Writer wr = new OutputStreamWriter(os); // criação de um escritor
				BufferedWriter br = new BufferedWriter(wr); // adiciono a um escritor de buffer

				br.write(novoTexto);
				br.newLine();

				br.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.texto = novoTexto;

		txtTesteDeImpressora.setText(this.texto);

		carregaComboImpressoras();
		criarJanela();

	}

	public EscolherImpressoraViewEtiquetaAction(Venda venda, String docCupom, String nomeCupom) {
		eventoBotao();
		// testando quebra delinhas funcao
		List<ItemVenda> itens = new ItemVendaDao().getItemVendaIdVenda(venda.getId());

		String lista = "	                CUPOM FISCAL           \n" + "		                                   \n"
				+ "CONSUMIDOR: " + nomeCupom + "\n" + "CPF/CNPJ:   " + docCupom + "\n" + "Pedido: " + venda.getId()
				+ "         " + venda.getDataVenda() + "          \n" + "Itens:                                    \n";

		lista = lista + "COD DESC PREÇO QTDE SUBTOTAL    \n";

		for (int i = 0; i < itens.size(); i++) {
			double subtotal = 0;
			if (itens.get(i).getProduto().getUnidade().contains("UN")) {
				subtotal = subtotal + itens.get(i).getPrecoUnitario() * itens.get(i).getQuantidade();
			}

			if (itens.get(i).getProduto().getUnidade().contains("KG")) {
				subtotal = subtotal + itens.get(i).getPrecoUnitario() * itens.get(i).getQuantidade() / 1000;
			}
			lista = lista + (i + 1) + " - " + itens.get(i).getProduto().getNome() + " "
					+ itens.get(i).getProduto().getUnidade() + " " + itens.get(i).getProduto().getPreco() + " "
					+ itens.get(i).getQuantidade() + " " + subtotal + "\n";

		}

		lista = lista + "\n Obrigado pela preferência! \n\n Volte sempre!";
		lista = lista + "\n                      TOTAL: " + calculaTotal(itens);
		this.texto = lista;

		System.out.println(venda.getEntrada());

		String novoTexto = lista;

		File file = new File("novoCupom.txt");
		if (!file.exists()) {
			System.out.println("Existe");
			try {
				file.createNewFile();
				System.out.println("Arquivo criado!");

				// Fluxo de saida de um arquivo
				OutputStream os = new FileOutputStream("novoCupom.txt"); // nome do arquivo que será escrito
				Writer wr = new OutputStreamWriter(os); // criação de um escritor
				BufferedWriter br = new BufferedWriter(wr); // adiciono a um escritor de buffer

				br.write(novoTexto);
				br.newLine();

				br.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.texto = novoTexto;

		txtTesteDeImpressora.setText(this.texto);

		carregaComboImpressoras();
		criarJanela();

	}

	public EscolherImpressoraViewEtiquetaAction(Etiqueta etiqueta) {
		eventoBotao();
		this.texto = etiqueta.montaEtiqueta();

		File file = new File("etiqueta.txt");
		if (!file.exists()) {
			System.out.println("Existe");
			try {
				file.createNewFile();
				System.out.println("Arquivo criado!");

				// Fluxo de saida de um arquivo
				OutputStream os = new FileOutputStream("etiqueta.txt"); // nome do arquivo que será escrito
				Writer wr = new OutputStreamWriter(os); // criação de um escritor
				BufferedWriter br = new BufferedWriter(wr); // adiciono a um escritor de buffer

				br.write(etiqueta.montaEtiqueta());
				br.newLine();

				br.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		Etiqueta etiqueta1 = new Etiqueta();

		etiqueta1.setCidade("ASSIS/SP");
		etiqueta1.setData(textData.getText());
		etiqueta1.setDescricao("CANCELAMENTO DE ETIQUETAS");
		etiqueta1.setFolha(textFolha.getText());
		etiqueta1.setLivro(textLivro.getText());
		etiqueta1.setFuncao("ESCREVENTE AUTORIZADO");
		etiqueta1.setMotivo(textMotivo.getText());
		etiqueta1.setFuncionario(comboFuncionario.getText());
		etiqueta1.setData("29/07/2024");
		this.texto = etiqueta1.montaEtiqueta();

		txtTesteDeImpressora.setText(this.texto);

		carregaComboImpressoras();
		criarJanela();

	}

	public EscolherImpressoraViewEtiquetaAction(String texto) {

		eventoBotao();
		carregaComboImpressoras();

		this.texto = texto;
		txtTesteDeImpressora.setText(this.texto);
		criarJanela();

	}

	public void criarJanela() {
		uteis.Interface.centralizarJanelaModal(shell);
		uteis.Interface.manterJanelaShell(shell);

	}

	private void eventoBotao() {

		textData.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {

				getDataText();

			}
		});

		textData.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String texto = textData.getText();
				String textoNormalizer = removerAcentos(texto);
				System.out.println(textoNormalizer);
				if (textoNormalizer.length() == 8 && !textoNormalizer.contains("-")) {

					String dia = textoNormalizer.substring(0, 2);
					String mes = textoNormalizer.substring(2, 4);
					String ano = textoNormalizer.substring(4, 8);

					// int diaInt = Integer.valueOf(dia);
					// int mesInt = Integer.valueOf(mes);
					// int anoInt = Integer.valueOf(ano);

					String data = dia + "/" + mes + "/" + ano;
					try {
						Date dat = sdf.parse(data);
						textData.setText(sdf.format(dat));
						atualizaEtiqueta();

					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					// System.out.println(mes);
					// System.out.println(ano);

				} else {
					System.out.println("Data inválida");
				}
			}

			public String removerAcentos(String str) {
				return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("/", "");
			}
		});

		comboFuncionario.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				atualizaEtiqueta();
			}

		});

		textData.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {

				// SimpleDateFormat sdfIn = new SimpleDateFormat("dd/MM/yyyy");
				// textData.setText(sdfIn.format(textData.getText()));
			}
		});

		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				if (index > -1) {
					texto = txtTesteDeImpressora.getText();
					if (!texto.isEmpty() || !texto.contains("")) {

						imprimir(index, quebraLinha(60, texto).toString());
					}
				}
			}
		});
		comboImpressora.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (comboImpressora.getSelectionIndex() > -1) {
					lbl.setText("Impressora: " + comboImpressora.getText());
					index = comboImpressora.getSelectionIndex();
					System.out.println(comboImpressora.getSelectionIndex());
				}
			}
		});
	}

	public void imprimir(int index, String texto) {

		try {
			PrintService impressora = services[index]; // escolhi a 3. impressora listada

			DocPrintJob dpj = impressora.createPrintJob();
			InputStream stream = new ByteArrayInputStream(new EncodeUTF8().encodeUTF8(texto));

			DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;

			Doc doc = new SimpleDoc(stream, flavor, null);
			dpj.print(doc, null);

		} catch (PrintException e) {
			e.printStackTrace();
		}
	}

	public void carregaComboImpressoras() {

		services = PrintServiceLookup.lookupPrintServices(null, null);
		// lista todas as impressoras instaladas
		for (PrintService element : services) {
			System.out.println(element.getName());
			comboImpressora.add(element.getName());
		}

	}

	public static StringBuilder quebraLinha(int limiteLinha, String texto) {

		StringBuilder novoTexto = new StringBuilder();

		String[] palavras = texto.split(" ");

		int contadorQntLetras = 0;

		for (String palavra : palavras) {

			if (contadorQntLetras + palavra.length() >= limiteLinha) {
				contadorQntLetras = 0;
				novoTexto.append('\n');
			}

			novoTexto.append(palavra);
			novoTexto.append(' ');
			contadorQntLetras += palavra.length() + 1;
		}

		return novoTexto;
	}

	private void atualizaEtiqueta() {
		Etiqueta etiqueta = new Etiqueta();
		etiqueta.setCidade("ASSIS/SP");
		etiqueta.setData(textData.getText());
		etiqueta.setLivro(textLivro.getText());
		etiqueta.setFolha(textFolha.getText());
		etiqueta.setMotivo(textMotivo.getText());
		etiqueta.setFuncionario(comboFuncionario.getText());
		txtTesteDeImpressora.setText(etiqueta.montaEtiqueta());

	}

	public static void main(String[] args) {
     
      
		   // Verifica se há parâmetros
        if (args.length > 0) {
            // Itera sobre os parâmetros e os imprime
        	String texto = "";
            for (String arg : args) {
                System.out.println("Parâmetro: " + arg);
               texto = texto + arg;
              
                
            }
            //JOptionPane.showMessageDialog(null, texto);
            new EscolherImpressoraViewEtiquetaAction(texto);
            
            
        } else {
           // System.out.println("Nenhum parâmetro foi passado..."+texto);
         
            new EscolherImpressoraViewEtiquetaAction();
            	
            
        }
      
	
	}
}
