package view;

import org.eclipse.jface.resource.FontDescriptor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class EscolherImpressoraViewEtiquetas {

	protected Shell shell;
	protected Combo comboImpressora;
	private LocalResourceManager localResourceManager;
	protected Label lbl;
	protected Text txtTesteDeImpressora;
	protected Button btnNewButton;
	protected Text textLivro;
	protected Text textFolha;
	protected Text textData;
	protected Text textMotivo;
	protected Combo comboFuncionario;
	private Group grpDadosDaEtiqueta;

	public EscolherImpressoraViewEtiquetas() {
		createContents();
	}

	protected void createContents() {
		shell = new Shell();
		createResourceManager();
		shell.setImage(localResourceManager
				.create(ImageDescriptor.createFromFile(EscolherImpressoraViewEtiquetas.class, "/icons/logo1.png")));
		shell.setSize(613, 599);
		shell.setText("Impressão de documentos");

		comboImpressora = new Combo(shell, SWT.NONE);

		comboImpressora.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 14, SWT.NORMAL)));
		comboImpressora.setBounds(31, 447, 522, 33);

		lbl = new Label(shell, SWT.NONE);
		lbl.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 13, SWT.BOLD)));
		lbl.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_DARK_GREEN));
		lbl.setBounds(34, 486, 522, 33);

		btnNewButton = new Button(shell, SWT.NONE);

		btnNewButton.setBounds(286, 525, 75, 25);
		btnNewButton.setText("Imprimir");

		txtTesteDeImpressora = new Text(shell,
				SWT.BORDER | SWT.WRAP | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL | SWT.MULTI);
		txtTesteDeImpressora
				.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 11, SWT.NORMAL)));
		txtTesteDeImpressora.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_GREEN));
		txtTesteDeImpressora.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_WIDGET_FOREGROUND));
		txtTesteDeImpressora.setBounds(31, 246, 522, 174);

		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 27, SWT.NORMAL)));
		lblNewLabel.setBounds(37, 10, 522, 47);
		lblNewLabel.setText("CANCELAMENTO DE ETIQUETAS");

		grpDadosDaEtiqueta = new Group(shell, SWT.NONE);
		grpDadosDaEtiqueta.setText("Dados da Etiqueta");
		grpDadosDaEtiqueta.setBounds(28, 77, 525, 156);

		Label lblNewLabel_1 = new Label(grpDadosDaEtiqueta, SWT.NONE);
		lblNewLabel_1.setBounds(3, 17, 55, 25);
		lblNewLabel_1.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.BOLD)));
		lblNewLabel_1.setText("Livro");

		textLivro = new Text(grpDadosDaEtiqueta, SWT.BORDER);
		textLivro.setBounds(110, 15, 76, 28);
		textLivro.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.NORMAL)));

		Label lblNewLabel_1_1 = new Label(grpDadosDaEtiqueta, SWT.NONE);
		lblNewLabel_1_1.setBounds(276, 17, 55, 25);
		lblNewLabel_1_1.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.BOLD)));
		lblNewLabel_1_1.setText("Folha");

		textFolha = new Text(grpDadosDaEtiqueta, SWT.BORDER);
		textFolha.setBounds(357, 15, 76, 28);
		textFolha.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.NORMAL)));

		Label lblNewLabel_2 = new Label(grpDadosDaEtiqueta, SWT.NONE);
		lblNewLabel_2.setBounds(3, 54, 55, 25);
		lblNewLabel_2.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.BOLD)));
		lblNewLabel_2.setText("Data");

		textData = new Text(grpDadosDaEtiqueta, SWT.BORDER);

		textData.setBounds(110, 52, 135, 28);

		textData.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.NORMAL)));

		Label lblNewLabel_2_1 = new Label(grpDadosDaEtiqueta, SWT.NONE);
		lblNewLabel_2_1.setBounds(3, 92, 55, 25);
		lblNewLabel_2_1.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.BOLD)));
		lblNewLabel_2_1.setText("Motivo");

		textMotivo = new Text(grpDadosDaEtiqueta, SWT.BORDER);
		textMotivo.setBounds(184, 89, 249, 28);
		textMotivo.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.NORMAL)));

		Label lblNewLabel_2_1_1 = new Label(grpDadosDaEtiqueta, SWT.NONE);
		lblNewLabel_2_1_1.setBounds(3, 124, 101, 25);
		lblNewLabel_2_1_1.setText("Funcionário");
		lblNewLabel_2_1_1.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.BOLD)));

		comboFuncionario = new Combo(grpDadosDaEtiqueta, SWT.NONE);
		comboFuncionario.setItems(new String[] { "CRISTIANO SALES BECHELI\t", "PATRICIA GREGORIO SILVA",
				"JOSE AMERICO DOICHE JUNIOR", "LOURIVAL GAMA DA SILVA", "DEBORA MAZZO DELGADO TAVARES\t" });
		comboFuncionario.setBounds(194, 124, 239, 29);

		comboFuncionario.setFont(localResourceManager.create(FontDescriptor.createFrom("Segoe UI", 12, SWT.NORMAL)));
		grpDadosDaEtiqueta.setTabList(new Control[] { textLivro, textFolha, textData, textMotivo, comboFuncionario });
		shell.setTabList(new Control[] { grpDadosDaEtiqueta, comboImpressora, btnNewButton });

	}

	private void createResourceManager() {
		localResourceManager = new LocalResourceManager(JFaceResources.getResources(), shell);
	}
}
