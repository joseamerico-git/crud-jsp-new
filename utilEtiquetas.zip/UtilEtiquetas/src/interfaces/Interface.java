package interfaces;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Interface {
	public static void manterJanelaShell(Shell shell) {

		Display display = Display.getDefault();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	public static void centralizarJanelaModal(Shell shell) {

		Display display = Display.getDefault();
		int width = display.getClientArea().width;
		int height = display.getClientArea().height;
		shell.setLocation(((width - shell.getSize().x) / 2) + display.getClientArea().x,
				((height - shell.getSize().y) / 2) + display.getClientArea().y);
	}

}
